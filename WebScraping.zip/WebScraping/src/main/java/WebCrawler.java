import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class WebCrawler {

	//Fields to keep track of pages already visited and max number of pages it can visit
	private static final int MAX_PAGES = 25;
	private Set<String> pagesVisited = new HashSet<String>();
	private List<String> pagesWordFound = new LinkedList<String>();
	private List<String> pagesToVisit = new LinkedList<String>();
	
        public void searchURL (String url, String keyword) {
                while(this.pagesVisited.size() < MAX_PAGES) {
                        String currentURL;
                        WebCrawlerNode node = new WebCrawlerNode();
                        if(this.pagesToVisit.isEmpty()) {
                                currentURL = url;
                                this.pagesVisited.add(url);
                        }else {
                                currentURL = this.nextURL();
                        }
                        node.crawl(currentURL);

                        boolean foundsuccess = node.searchKeyWord(keyword);
                        if(foundsuccess) {
                                System.out.println(String.format("Success! Word %s found at %s", keyword, currentURL));
                                websitesWordFound(currentURL);
                                break;
                        }
                        this.pagesToVisit.addAll(node.getLinks());
                }
                System.out.println(String.format("Done! We have visited %s web pages", this.pagesVisited.size()));
        }
		
        //Get URL of first site to view; if found in the pagesVisited set, then go the next URL
        private String nextURL() {
                String nextURL; 
                do {
                        nextURL = this.pagesToVisit.remove(0);
                }while(this.pagesVisited.contains(nextURL));
                this.pagesVisited.add(nextURL);

                return nextURL;
        }

        private static void websitesWordFound(String link){
            try {
              FileWriter fr = new FileWriter ("websiteswordfound.txt");
              BufferedWriter out = new BufferedWriter(fr);
              out.write(link);
              out.newLine();
              out.close();
            } 
            catch (Exception e) {
              System.out.println(e);   
            }
        }

}