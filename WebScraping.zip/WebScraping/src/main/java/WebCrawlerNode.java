import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;
import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;	


public class WebCrawlerNode {
	
	//Fake USER so web browser thinks it is a normal web user
	private static final String USER = "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/13.0.782.112 Safari/535.1"; 	
	//List of URLs
	private List<String> links = new LinkedList<String>();
	//Web page
	private Document htmldocument;
	
	public boolean crawl (String url) {
            try {
                    Connection connection = Jsoup.connect(url).userAgent(USER);
                    Document htmldocument = connection.get();
                    this.htmldocument = htmldocument;

                    if(connection.response().statusCode() == 200) {
                            System.out.println("Obtained web page at " + url);
                    }
                    if(!connection.response().contentType().contains("text/html")) {
                            System.out.println("Failure! Recieved something other than HTML");
                            return false;
                    }

                    Elements linksOnPage = htmldocument.select("a[href]");
                    System.out.println("Found (" + linksOnPage.size() + ") links");
                    for(Element link : linksOnPage) {
                            this.links.add(link.absUrl("href"));
                    }
                    websitesCrawled(links);
                    readWebsites();
                    return true;
            }catch(IOException e) {
                    //Not successful in the HTTP request
                    System.out.println("Error in HTTP request: " + e);
                    return false;
            }
	}
	
	//Searches for the keyword
	public boolean searchKeyWord(String keyword) {
            if(this.htmldocument == null) {
                    System.out.println("ERROR! crawl() must be called first before analysing document.");
                    return false;
            }

            System.out.println("Searching for the keyword: " + keyword + "...");
            String bodyText = this.htmldocument.body().text();
            return bodyText.toLowerCase().contains(keyword.toLowerCase());
	}
	
	
	//Returns relevant links on the page
	public List<String> getLinks(){
            return this.links;
	}
	
	private static void websitesCrawled(List<String> links){
            try {
              FileWriter fr = new FileWriter("Links.txt");
              PrintWriter pw = new PrintWriter(fr);
              ListIterator<String> itr = links.listIterator();
              for(String link : links) {
                  pw.print(link);
                  pw.println();
                  }
              pw.close();
            } 
            catch (Exception e) {
              System.out.println(e);   
            }
        }
        
        private static void readWebsites() throws FileNotFoundException, IOException{
            try{
                FileReader fr = new FileReader("Links.txt");
                BufferedReader br = new BufferedReader(fr);
                
                FileWriter fw = new FileWriter("finalLinks.txt");
                PrintWriter pw = new PrintWriter(fw);
                
                String line; 
                String unique;
                
                while((line = br.readLine()) != null){
                    if(line.contains("https://wwwnc.cdc.gov/travel/notices/")){
                        try {
                            unique = line.split("https://wwwnc.cdc.gov/travel/notices/watch/")[1].trim();
                            pw.print(unique);
                            pw.println();
                      }catch (Exception e) {
                        System.out.println(e);   
                      }
                    }
                }
                pw.close();
            }catch(FileNotFoundException e){
                System.out.println("File not found.");
            }
        }
}