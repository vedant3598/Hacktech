public class WebCrawlerTest {

	public static void main(String[] args) {
		WebCrawler spider = new WebCrawler();
		spider.searchURL("https://www.cdc.gov/coronavirus/2019-ncov/travelers/index.html", "China");
	}
}